#!/bin/bash
# @app      cahato/alpine-apache
# @author   cahato https://github.com/cahato

function a2setModule(){
    local enable=${1:-''}
    local   path=${3:-'/etc/apache2/httpd.conf'}
    local   scom=''
    local   rcom='\#'
    if [ ! -z $1 ] && [ ! -z "$2" ]; then
        if [ "$enable" = 1 ]; then
            scom='\#'
            rcom=''
        fi
        echo "$2"
        sed -i "s#${scom}LoadModule $2_module modules/mod_$2.so#${rcom}LoadModule $2_module modules/mod_$2.so#" "$path"
    fi
}
if [ ! -f /usr/bin/php ]; then
    ln -s /usr/bin/php7 /usr/bin/php
fi
if [ ! -f /usr/lib/libxml2.so ]; then
    ln -s /usr/lib/libxml2.so.2 /usr/lib/libxml2.so
fi

if [ ! -d /run/apache2 ]; then
    mkdir /run/apache2
fi
chmod -R 755 /scripts/pre-init.d
mkdir -p /run/apache2
chown apache:apache /run/apache2

initTitle "Apache" "Loading Modules"
a2setModule 1 "rewrite"
a2setModule 1 "mpm_prefork"
a2setModule 1 "slotmem_shm"
a2setModule 1 "heartmonitor"
#~ a2setModule 1 "watchdog"
initTitle "Apache" "Removing Modules"
a2setModule 0 "mpm_event"
a2setModule 0 "proxy_fdpass" /etc/apache2/conf.d/proxy.conf

sed -i "s|;*date.timezone =.*|date.timezone = ${TZ}|i" /etc/php7/php.ini
sed -ir 's/expose_php = On/expose_php = Off/' /etc/php7/php.ini
echo -e "\nIncludeOptional /app/vhost" >> /etc/apache2/httpd.conf
unset tmpsed
